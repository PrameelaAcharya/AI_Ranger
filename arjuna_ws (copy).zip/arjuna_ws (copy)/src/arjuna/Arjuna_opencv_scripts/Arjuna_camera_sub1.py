#!/home/arjuna/yolo_env/bin/python

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from std_msgs.msg import Float32, String
from ultralytics import YOLO
import tensorflow as tf
from tensorflow.keras.models import load_model
import time

# Custom CvBridge replacement
class CustomCvBridge:
    def imgmsg_to_cv2(self, img_msg, desired_encoding="passthrough"):
        if img_msg.encoding == "bgr8":
            cv_image = np.frombuffer(img_msg.data, dtype=np.uint8).reshape(
                img_msg.height, img_msg.width, 3
            )
        elif img_msg.encoding == "mono8":
            cv_image = np.frombuffer(img_msg.data, dtype=np.uint8).reshape(
                img_msg.height, img_msg.width
            )
        else:
            raise ValueError(f"Unsupported encoding: {img_msg.encoding}")
        return cv_image


class DetectionDisplay:
    def __init__(self):
        rospy.init_node('wound_species_display', anonymous=True)

        self.bridge = CustomCvBridge()
        self.rgb_frame = None
        self.depth_value = 0
        self.fps = 0
        self.frame_count = 0
        self.start_time = rospy.get_time()
        self.depth_text = "Depth: -- cm"
        self.text_color = (0, 255, 0)

        # Load wound detection model (YOLO .pt)
        rospy.loginfo("Loading YOLO wound model...")
        self.wound_model = YOLO("/home/arjuna/Downloads/best.pt")  # update path

        # Load species classification model (.h5)
        rospy.loginfo("Loading Keras species model...")
        self.species_model = load_model("/home/arjuna/Downloads/animal_classifier_1.h5")  # update path
        with open("/home/arjuna/Downloads/animal_species.txt", "r") as f:   # update path for Ubuntu
    	    species_classes = [line.strip() for line in f.readlines()]  # update with actual class names

        # ROS subscriptions
        rospy.Subscriber('/frames', Image, self.rgb_callback)
        rospy.Subscriber('/oak/depth_value', Float32, self.depth_callback)

        # Publisher for results
        self.result_pub = rospy.Publisher("/wound_species/results", String, queue_size=10)

        rospy.loginfo("Node initialized")

    def preprocess_species(self, frame):
        """ Preprocess frame for species model (adjust to your training setup). """
        img = cv2.resize(frame, (224, 224))   # change to model input size
        img = img.astype("float32") / 255.0
        img = np.expand_dims(img, axis=0)     # batch dimension
        return img

    def rgb_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.rgb_frame = frame

            # FPS counter
            self.frame_count += 1
            elapsed = rospy.get_time() - self.start_time
            if elapsed > 1.0:
                self.fps = self.frame_count / elapsed
                self.frame_count = 0
                self.start_time = rospy.get_time()

            # ---- Run wound detection (YOLO) ----
            wound_results = self.wound_model.predict(frame, verbose=False)
            frame = wound_results[0].plot()

            wound_labels = [self.wound_model.names[int(c)] for c in wound_results[0].boxes.cls] \
                if len(wound_results[0].boxes) > 0 else ["None"]

            # ---- Run species classification (.h5) ----
            species_input = self.preprocess_species(frame)
            pred = self.species_model.predict(species_input, verbose=0)
            species_idx = np.argmax(pred)
            species_label = self.species_classes[species_idx]

            # Draw info on frame
            self.draw_info(frame, wound_labels, species_label)

        except Exception as e:
            rospy.logerr(f"Error processing frame: {e}")

    def depth_callback(self, msg):
        self.depth_value = msg.data
        if self.depth_value < 0:
            self.depth_text = "Depth: Too close"
            self.text_color = (0, 0, 255)
        else:
            self.depth_text = f"Depth: {self.depth_value:.1f} cm"
            if self.depth_value < 30:
                self.text_color = (0, 0, 255)
            elif self.depth_value < 100:
                self.text_color = (0, 255, 0)
            else:
                self.text_color = (255, 255, 0)

    def draw_info(self, frame, wound_labels, species_label):
        display_frame = frame.copy()

        # Overlay depth + FPS
        cv2.rectangle(display_frame, (10, 10), (350, 85), (0, 0, 0), -1)
        cv2.putText(display_frame, self.depth_text, (15, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, self.text_color, 2)
        cv2.putText(display_frame, f"FPS: {self.fps:.1f}", (15, 70),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

        # Overlay detection results
        info_text = f"Wound: {', '.join(wound_labels)} | Species: {species_label}"
        cv2.putText(display_frame, info_text, (15, 110),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        # Publish as ROS topic
        result_msg = f"{info_text} | Depth: {self.depth_value:.1f} cm"
        self.result_pub.publish(result_msg)

        # Show in OpenCV window
        cv2.imshow("Wound & Species Detection", display_frame)
        cv2.waitKey(1)

    def run(self):
        rospy.spin()


if __name__ == "__main__":
    try:
        node = DetectionDisplay()
        node.run()
    except rospy.ROSInterruptException:
        pass
    finally:
        cv2.destroyAllWindows()

