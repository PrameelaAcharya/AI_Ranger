# animal_detection_node.py (Python3)

import json
import cv2
from ultralytics import YOLO
import keras
import numpy as np
import tensorflow as tf

# Load models
model = keras.models.load_model("/home/arjuna/Downloads/animal_classifier_1.h5",compile=False)
model.save("/home/arjuna/Downloads/animal_classifier_tf2.h5")
species_model = tf.keras.models.load_model("/home/arjuna/Downloads/animal_classifier_tf2.h5", compile=False)
wound_model = YOLO("/home/arjuna/Downloads/best.pt")

# Load species names
with open("/home/arjuna/Downloads/animal_species.txt", "r") as f:
    species_names = [line.strip() for line in f.readlines()]

# Open camera
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    # ----- Species detection -----
    img_resized = cv2.resize(frame, (224, 224)) / 255.0
    img_resized = np.expand_dims(img_resized, axis=0)
    species_pred = species_model.predict(img_resized)
    species_id = np.argmax(species_pred)
    species_name = species_names[species_id]

    # ----- Wound detection -----
    wound_pred = wound_model(frame)
    wounded = len(wound_pred[0].boxes) > 0  # if YOLO detects a wound

    # ----- Result -----
    result = {
        "species": species_name,
        "wounded": wounded
    }

    # Save result to JSON (bridge will read this)
    with open("/tmp/animal_result.json", "w") as f:
        json.dump(result, f)

    # Optional: display camera output
    cv2.imshow("Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

