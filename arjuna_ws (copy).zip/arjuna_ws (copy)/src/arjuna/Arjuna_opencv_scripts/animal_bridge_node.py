# animal_bridge_node.py (Python2, ROS Melodic)
#!/usr/bin/env python
import rospy
import json
from std_msgs.msg import String
import time

def main():
    rospy.init_node("animal_bridge_node", anonymous=True)
    pub = rospy.Publisher("/animal_detection", String, queue_size=10)
    rate = rospy.Rate(5)  # 5 Hz

    while not rospy.is_shutdown():
        try:
            with open("/tmp/animal_result.json", "r") as f:
                data = json.load(f)
            pub.publish(json.dumps(data))
        except Exception as e:
            rospy.logwarn("No detection data yet: %s", e)
        rate.sleep()

if __name__ == "__main__":
    main()

