import keras

# Load old Keras model
model = keras.models.load_model("/home/arjuna/Downloads/animal_classifier_1.h5", compile=False)

# Save in TensorFlow 2.x compatible format
model.save("/home/arjuna/Downloads/animal_classifier_tf2.h5")
print("✅ Model converted and saved as animal_classifier_tf2.h5")

